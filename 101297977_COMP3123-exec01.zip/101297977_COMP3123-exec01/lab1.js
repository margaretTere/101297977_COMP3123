// //COMP 3123 – Full Stack Development – Lab 1 
// // Margaret Terechtchenko 101297977

// //Exercise 1:  

// //Write a JavaScript program to capitalize the first letter of each word of a given string. 

 function cap(word) { 
    let c = word[0].toUpperCase() + word.substring(1);   
    return c
}

function capitalize(s){
    let b = s.split(' ');
    let result = b.map(cap);
    return result.join(' ');
}

let a = "the quick brown fox";
console.log(capitalize(a));


// //Exercise 2:  

// //Write a JavaScript program to find the largest of three given integers. 



function max1(i1,i2,i3){
    return Math.max(i1,i2,i3);
}

console.log(max1(1000, 510, 440));


// //Exercise 3:  

// //Write a JavaScript program to move last three character to the start of a given string. 
// //The string length must be greater or equal to three. 

function right(w){
    if(w.length < 3){
        return "Error. Provide longer word!";
    }

    let l = w.length;
    let lastpart = w.substring(l-3);
    let firstpart = w.substring(0,l-3);

    return lastpart + firstpart;
}


let w = "Python";
console.log(right(w));


//Exercise 4:  

//Write a JavaScript program to find the types of a given angle. 
//Types of angles: 
//• Acute angle: An angle between 0 and 90 degrees. 
//• Right angle: An 90 degree angle. 
//• Obtuse angle: An angle between 90 and 180 degrees. 
//• Straight angle: A 180 degree angle. 
function angleType(degrees){
    if(degrees > 0 && degrees < 90){
        return "Acute angle";
    }else if(degrees === 90){
        return "Right angle";
    }else if(degrees > 90 && degrees < 180){
        return "Obtuse angle";
    }else if(degrees === 180){
        return "Straight angle";
    }else{
        return "Pease keep your number > 0 and <= 180";
    }
}
console.log(angleType(120));


//Exercise 5:  

//Write a JavaScript program to find the maximum possible sum of some of its k consecutive numbers 
//(numbers that follow each other in order.) of a given array of positive integers. 

let num = [1,2,3,14,5];
let n = 2
r = [];
for(let i=0; i<= num.length; i++){
    if((i + n) > num.length){
        break;
    }
    let s = num.slice(i, i + n);
    r.push(s.reduce((accumlator, current)=> accumlator + current));
    
}
console.log(r);
console.log(Math.max(...r));
