//Comp3123
//Lab2 By: Margaret Terechtchenko 101297977
//Exercise 1: Rewrite the following code block using 
//ES6 syntax, ie. const, let, arrow function, template literals and for..of

const gretter = (myArray, counter) =>{
    const greetText = 'Hello';

    for(let value of myArray){
       console.log(`${greetText} ${value}`);
    }

};

gretter(['Randy Savage', 'Ric Flair', 'Hulk Hogan'], 3);


//Exercise 2: 

//Using destructuring assignment syntax and the spread operator,
//write a function will capitalize the first letter of a string. 

const word = 'fooBar';
const word1 = 'nodejs'

const cap = ([...param]) =>{
    param[0] = param[0].toUpperCase();
   
    return param.join('');
};

console.log(cap(word));
console.log(cap(word1));


//Exercise 3: 

//Using array.proto.map create function to use the capitalize method in 
//Exercise 2 to upper case the first character of each Color in the following array.. 

 const colors = ['red', 'green', 'blue']

 console.log(colors.map(cap));


 //Exercise 4: 

//Using array.proto.filter create a function that will filter out all the 
//values of the array that are less than twenty. 

const values = [1,60,34,30,20,5]

const filterLessThan20 = n => n < 20;

console.log(values.filter(filterLessThan20));


//Exercise 5: 

//Using array.proto.reduce create calculate the sum and product of a given array.

const nums = [1, 2, 3, 4]

const calculateSum = (total, number) => total + number;

const calculateProduct = (product, number) => product * number;

console.log(nums.reduce(calculateSum, 0));
console.log(nums.reduce(calculateProduct, 1));

//Exercise 6: 

//Using ES6 syntax for class and subclass using extends to create a Sedan subclass which derives from Car Class. 
//The parameters for the Car class is the model and year. The parameters for the subclass is the model, year and balance. 

//Use the super key word in the Sedan subclass to set the model and name in base Car constructor.
 
class Car {
    constructor(model, year){
        this.model = model;
        this.year = year;
    }

    details = function(){
        return `Model: ${this.model},  Year: ${this.year}`;
    };
}
class Sedan extends Car{
    constructor(model, year, balance){
        super(model, year);
        this.balance = balance;
    }

    info = function(){
        return `${this.model} has a balance of $${this.balance}`;
    };

}


const car2 = new Car('Pontaic Firebird', 1976);
console.log(car2.details());


const sedan = new Sedan('Volvo SD', 2018, 30000);
console.log(sedan.info());